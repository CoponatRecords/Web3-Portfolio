const axios = require("axios");

exports.handler = async (event) => {
  const { sellToken, buyToken, sellAmount, takerAddress } = event.queryStringParameters;

  const url = `https://api.0x.org/swap/permit2/quote?chainId=42161&sellToken=${sellToken}&buyToken=${buyToken}&sellAmount=${sellAmount}&taker=${takerAddress}`;

  try {
    const response = await axios.get(url, {
      headers: {
        "0x-api-key": process.env.ZERO_X_API_KEY,
        "0x-version": "v2"
      }
    });

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(response.data)
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
};
